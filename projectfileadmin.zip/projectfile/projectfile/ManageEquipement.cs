﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectfile
{
    public partial class ManageEquipement : Form
    {
        public ManageEquipement()
        {
            InitializeComponent();
        }

        private void ManageEquipement_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vitalitygymDataSet3.equipment' table. You can move, or remove it, as needed.
            this.equipmentTableAdapter.Fill(this.vitalitygymDataSet3.equipment);

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            string searchoption = guna2ComboBox1.SelectedItem.ToString();
            if (searchoption == "Equipment ID")
            {
                searchid();
            }
            else if (searchoption == "Equipment Name")
            {
                searchname();
            }
        }
        public void searchid()
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            string searchText = guna2TextBox1.Text.Trim();

            if (!int.TryParse(searchText, out int searchValue))
            {
                MessageBox.Show("Invalid search value. Please enter a valid integer value.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string searchQuery = "SELECT * FROM equipment WHERE eid = @SearchValue";

                using (SqlCommand command = new SqlCommand(searchQuery, connection))
                {
                    command.Parameters.AddWithValue("@SearchValue", searchValue);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Set the DataTable as the data source for the DataGridView
                        guna2DataGridView1.DataSource = dataTable;
                    }
                }
            }
        }

        public void searchname()
        {
            string searchText = guna2TextBox1.Text.ToLower();
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string searchQuery = "SELECT * FROM equipment WHERE LOWER(ename) LIKE @SearchText";

                using (SqlCommand command = new SqlCommand(searchQuery, connection))
                {
                    command.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Set the DataTable as the data source for the DataGridView
                        guna2DataGridView1.DataSource = dataTable;
                    }
                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admindashboard admindashboard = new Admindashboard();
            admindashboard.Show();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(connectionString);
            Connection.Open();

            // Step 2: Execute a SELECT query
            string query = "SELECT * FROM equipment";
            SqlCommand command = new SqlCommand(query, Connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            guna2DataGridView1.DataSource = dataTable;
            Connection.Close();
        }

        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            // Check if a row is selected
            if (guna2DataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row index
                int rowIndex = guna2DataGridView1.SelectedRows[0].Index;

                // Get the value of the primary key from the selected row
                int primaryKeyValue = (int)guna2DataGridView1.Rows[rowIndex].Cells["eidDataGridViewTextBoxColumn"].Value;

                // Confirmation dialog
                DialogResult result = MessageBox.Show("Are you sure you want to remove this equipment?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string deleteQuery = "DELETE FROM equipment WHERE eid = @PrimaryKeyValue";

                        using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                        {
                            command.Parameters.AddWithValue("@PrimaryKeyValue", primaryKeyValue);
                            command.ExecuteNonQuery();

                            // Remove the selected row from the DataGridView
                            guna2DataGridView1.Rows.RemoveAt(rowIndex);

                            MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void guna2GradientButton3_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO equipment (ename, ecompany, eprice, estatus) VALUES (@ename, @ecompany, @eprice, @estatus)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ename", guna2TextBox3.Text);
                    command.Parameters.AddWithValue("@ecompany", guna2TextBox2.Text);
                    command.Parameters.AddWithValue("@eprice", Convert.ToInt32(guna2TextBox6.Text));
                    command.Parameters.AddWithValue("@estatus", guna2TextBox5.Text);
                   

                    command.ExecuteNonQuery();
                    MessageBox.Show("Equipment added successfully.Refresh to view.");
                }
            }
        }

        private void guna2GradientButton4_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            if (guna2DataGridView1.SelectedRows.Count > 0)
            {
                int rowIndex = guna2DataGridView1.SelectedRows[0].Index;
                int equipmentID = Convert.ToInt32(guna2DataGridView1.Rows[rowIndex].Cells["eidDataGridViewTextBoxColumn"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "UPDATE equipment SET ename = @ename, ecompany = @ecompany, eprice = @eprice, estatus = @estatus  WHERE eid = @equipmentID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ename", guna2TextBox3.Text);
                        command.Parameters.AddWithValue("@ecompany", guna2TextBox2.Text);
                        command.Parameters.AddWithValue("@eprice", Convert.ToInt32(guna2TextBox6.Text));
                        command.Parameters.AddWithValue("@estatus", guna2TextBox5.Text);
                        command.Parameters.AddWithValue("@equipmentID", equipmentID);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Equipment updated successfully.Refresh to view.");
                    }
                }


            }
        }
    }
}
