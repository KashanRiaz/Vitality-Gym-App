﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectfile
{
    public partial class ManagePackages : Form
    {
        public ManagePackages()
        {
            InitializeComponent();
        }

        private void ManagePackages_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vitalitygymDataSet4.package' table. You can move, or remove it, as needed.
            this.packageTableAdapter.Fill(this.vitalitygymDataSet4.package);

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admindashboard admindashboard = new Admindashboard();
            admindashboard.Show();
        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            string searchoption = guna2ComboBox1.SelectedItem.ToString();
            if (searchoption == "Package ID")
            {
                searchid();
            }
            else if (searchoption == "Package Name")
            {
                searchname();
            }
        }

        public void searchid()
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            string searchText = guna2TextBox1.Text.Trim();

            if (!int.TryParse(searchText, out int searchValue))
            {
                MessageBox.Show("Invalid search value. Please enter a valid integer value.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string searchQuery = "SELECT * FROM package WHERE packageid = @SearchValue";

                using (SqlCommand command = new SqlCommand(searchQuery, connection))
                {
                    command.Parameters.AddWithValue("@SearchValue", searchValue);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Set the DataTable as the data source for the DataGridView
                        guna2DataGridView1.DataSource = dataTable;
                    }
                }
            }
        }

        public void searchname()
        {
            string searchText = guna2TextBox1.Text.ToLower();
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string searchQuery = "SELECT * FROM package WHERE LOWER(packagename) LIKE @SearchText";

                using (SqlCommand command = new SqlCommand(searchQuery, connection))
                {
                    command.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Set the DataTable as the data source for the DataGridView
                        guna2DataGridView1.DataSource = dataTable;
                    }
                }
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(connectionString);
            Connection.Open();

            // Step 2: Execute a SELECT query
            string query = "SELECT * FROM package";
            SqlCommand command = new SqlCommand(query, Connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            guna2DataGridView1.DataSource = dataTable;
            Connection.Close();
        }

        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            // Check if a row is selected
            if (guna2DataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected row index
                int rowIndex = guna2DataGridView1.SelectedRows[0].Index;

                // Get the value of the primary key from the selected row
                int primaryKeyValue = (int)guna2DataGridView1.Rows[rowIndex].Cells["packageidDataGridViewTextBoxColumn"].Value;

                // Confirmation dialog
                DialogResult result = MessageBox.Show("Are you sure you want to remove this Package?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        string deleteQuery = "DELETE FROM package WHERE packageid = @PrimaryKeyValue";

                        using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                        {
                            command.Parameters.AddWithValue("@PrimaryKeyValue", primaryKeyValue);
                            command.ExecuteNonQuery();

                            // Remove the selected row from the DataGridView
                            guna2DataGridView1.Rows.RemoveAt(rowIndex);

                            MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void guna2GradientButton3_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO package (packagename, packageprice, discount) VALUES (@packagename, @packageprice, @discount)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@packagename", guna2TextBox3.Text);
                    
                    command.Parameters.AddWithValue("@packageprice", Convert.ToInt32(guna2TextBox6.Text));
                    command.Parameters.AddWithValue("@discount", guna2TextBox5.Text);


                    command.ExecuteNonQuery();
                    MessageBox.Show("Package added successfully.Refresh to view.");
                }
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void guna2GradientButton4_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            if (guna2DataGridView1.SelectedRows.Count > 0)
            {
                int rowIndex = guna2DataGridView1.SelectedRows[0].Index;
                int packageID = Convert.ToInt32(guna2DataGridView1.Rows[rowIndex].Cells["packageidDataGridViewTextBoxColumn"].Value);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "UPDATE package SET packagename = @packagename, packageprice = @packageprice, discount = @discount WHERE packageid = @packageID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@packagename", guna2TextBox3.Text);

                        command.Parameters.AddWithValue("@packageprice", Convert.ToInt32(guna2TextBox6.Text));
                        command.Parameters.AddWithValue("@discount", guna2TextBox5.Text);
                        command.Parameters.AddWithValue("@packageID", packageID);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Package updated successfully.Refresh to view.");
                    }
                }


            }
        }
    }
}
