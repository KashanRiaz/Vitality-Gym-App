﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectfile
{
    public partial class Admindashboard : Form
    {
        public Admindashboard()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2CircleButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewFeeList m =new ViewFeeList();
            m.Show();

        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
           this.Hide();
           Manageclients m= new Manageclients();
            m.Show();
            
           
        }

        private void guna2CircleButton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            ManageTrainer m = new ManageTrainer();
            m.Show();
        }

        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            ManageEquipement m = new ManageEquipement();
            m.Show();
        }

        private void guna2CircleButton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            ManagePackages m = new ManagePackages();
            m.Show();
        }
    }
}
