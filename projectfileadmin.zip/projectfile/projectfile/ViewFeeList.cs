﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectfile
{
    public partial class ViewFeeList : Form
    {
        public ViewFeeList()
        {
            InitializeComponent();
            
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admindashboard admindashboard = new Admindashboard();
            admindashboard.Show();
        }

        private void ViewFeeList_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vitalitygymDataSet1.bills' table. You can move, or remove it, as needed.
            this.billsTableAdapter.Fill(this.vitalitygymDataSet1.bills);

        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            string searchoption = guna2ComboBox1.SelectedItem.ToString();
            if (searchoption == "Bill ID")
            {
                searchbid();
            }
            else if (searchoption == "Client ID")
            {
                searchcid();
            }
            else if(searchoption=="Bill Date")
            {
                guna2TextBox1.Hide();
                searchdate();

            }
        }

        private void guna2ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void searchcid()
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            string searchText = guna2TextBox1.Text.Trim();

            if (!int.TryParse(searchText, out int searchValue))
            {
                MessageBox.Show("Invalid search value. Please enter a valid integer value.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string searchQuery = "SELECT * FROM bills WHERE clientid = @SearchValue";

                using (SqlCommand command = new SqlCommand(searchQuery, connection))
                {
                    command.Parameters.AddWithValue("@SearchValue", searchValue);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Set the DataTable as the data source for the DataGridView
                        guna2DataGridView1.DataSource = dataTable;
                    }
                }
            }
        }

        public void searchbid()
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            string searchText = guna2TextBox1.Text.Trim();

            if (!int.TryParse(searchText, out int searchValue))
            {
                MessageBox.Show("Invalid search value. Please enter a valid integer value.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string searchQuery = "SELECT * FROM bills WHERE bid = @SearchValue";

                using (SqlCommand command = new SqlCommand(searchQuery, connection))
                {
                    command.Parameters.AddWithValue("@SearchValue", searchValue);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Set the DataTable as the data source for the DataGridView
                        guna2DataGridView1.DataSource = dataTable;
                    }
                }
            }
        }
        public void searchdate()
        {
            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            DateTime searchDateTime = guna2DateTimePicker1.Value;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string searchQuery = "SELECT * FROM bills WHERE billdate >= @SearchDateTime";

                using (SqlCommand command = new SqlCommand(searchQuery, connection))
                {
                    command.Parameters.AddWithValue("@SearchDateTime", searchDateTime);

                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Set the DataTable as the data source for the DataGridView
                        guna2DataGridView1.DataSource = dataTable;
                    }
                }
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {

            string connectionString = @"Data Source=DESKTOP-BTUEVAQ\SQLEXPRESS;Initial Catalog=vitalitygym;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(connectionString);
            Connection.Open();

            // Step 2: Execute a SELECT query
            string query = "SELECT * FROM bills";
            SqlCommand command = new SqlCommand(query, Connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            guna2DataGridView1.DataSource = dataTable;
            Connection.Close();
        }

        private void guna2DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
