﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VitalityGym
{
    public partial class TrainerLogin : Form
    {
        private bool Verify()
        {
            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();

            string query = "SELECT * FROM  Trainer WHERE trainername = '" + textBox1.Text + "' AND trainerpassword = '" + textBox2.Text + "'";
            SqlCommand command = new SqlCommand(query, Connection);
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows == true)
            {
                return true;
            }
            else
            {
                return false;
            }

            command.Dispose();
            Connection.Close();

        }
        public TrainerLogin()
        {
            InitializeComponent();
        }

        private void TrainerLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrontForm front = new FrontForm();
            this.Hide();
            front.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Verify() == true)
            {
                MessageBox.Show("Correct Credentials");
            }
            else if (Verify() == false)
            {
                MessageBox.Show("Please enter your Username and Password");
            }
            else
            {
                MessageBox.Show("No entry found.");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
