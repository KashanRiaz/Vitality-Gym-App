﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace VitalityGym
{
    public partial class AddPackage : Form
    {
        public AddPackage()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string Name = textBox1.Text;
            string Price = textBox2.Text;


            Insert(Name, Price);

            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;

            MessageBox.Show("Added Successfully");
        }

        public void Insert(string name, string price)
        {
            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();
            string query = "INSERT INTO Package (packagename, packageprice) VALUES (@name, @price)";
            using (SqlCommand command = new SqlCommand(query, Connection))
            {
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@price", price);
                command.ExecuteNonQuery();
                command.Dispose();


            }
            Connection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdminDashboard dash = new AdminDashboard();
            dash.Show();
            this.Close();
        }
    }
}
