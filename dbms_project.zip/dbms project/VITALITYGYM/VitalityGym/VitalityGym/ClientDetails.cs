﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VitalityGym
{
    public partial class ClientDetails : Form
    {
        public ClientDetails()
        {
            InitializeComponent();
        }

        private void UpdateClientData()
        {
            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection connection = new SqlConnection(path);
            connection.Open();

            string name = textBox1.Text;
            string email = textBox2.Text;
            string city = textBox3.Text;
            string package = textBox4.Text;

            string query = "UPDATE Client SET clientname = @Name, clientcity = @City, clientpackage = @Package WHERE clientemail = @Email";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Name", name);
            command.Parameters.AddWithValue("@City", city);
            command.Parameters.AddWithValue("@Package", package);
            command.Parameters.AddWithValue("@Email", email);

            int rowsAffected = command.ExecuteNonQuery();

            connection.Close();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Client information updated successfully!");

                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                
            }
            else
            {
                MessageBox.Show("Failed to update client information.");
            }
        }
        private void ClientDetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vitalityDataSet.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter1.Fill(this.vitalityDataSet.Client);
            // TODO: This line of code loads data into the 'vitality.Client' table. You can move, or remove it, as needed.
            this.clientTableAdapter.Fill(this.vitality.Client);

        }


        private void DeleteClient()
        {
            string email = textBox10.Text;

            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection connection = new SqlConnection(path);
            connection.Open();

            string query = "DELETE FROM Client WHERE clientemail = @Email";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Email", email);

            int rowsAffected = command.ExecuteNonQuery();

            connection.Close();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Client deleted successfully!");

                // Clear the email textbox
                textBox10.Text = "";
            }
            else
            {
                MessageBox.Show("Failed to delete client.");
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();

            // Step 2: Execute a SELECT query
            string query = "SELECT * FROM Client"; 
            SqlCommand command = new SqlCommand(query, Connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            Connection.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AdminDashboard dash = new AdminDashboard();
            dash.Show();
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            UpdateClientData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DeleteClient();
        }
    }
}
