﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VitalityGym
{
    public partial class TrainerDetails : Form
    {
        public TrainerDetails()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();

            // Step 2: Execute a SELECT query
            string query = "SELECT * FROM Trainer";
            SqlCommand command = new SqlCommand(query, Connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            Connection.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AdminDashboard admin = new AdminDashboard();
            admin.Show();
            this.Close();
        }

        private void TrainerDetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'vitalityDataSet1.Trainer' table. You can move, or remove it, as needed.
            this.trainerTableAdapter.Fill(this.vitalityDataSet1.Trainer);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
