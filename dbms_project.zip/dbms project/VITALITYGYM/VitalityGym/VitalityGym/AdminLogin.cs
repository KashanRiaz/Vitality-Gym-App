﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VitalityGym
{
    public partial class AdminLogin : Form
    {

        private bool Verify()
        {
            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();

            string query = "SELECT * FROM  Admin WHERE adminid = '" + textBox1.Text + "' AND adminpassword = '" + textBox2.Text + "'";
            SqlCommand command = new SqlCommand(query, Connection);
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows == true)
            {
                return true;
            }
            else
            {
                return false;
            }

            command.Dispose();
            Connection.Close();

        }
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrontForm front = new FrontForm();
            this.Hide();
            front.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Verify() == true)
            {
                AdminDashboard admin = new AdminDashboard();
                admin.Show();
                this.Close();
            }
            else if (Verify() == null)
            {
                MessageBox.Show("Please enter your Username and Password");
            }
            else
            {
                MessageBox.Show("No entry found.");
            }
        }
    }
}
