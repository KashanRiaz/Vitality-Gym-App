﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VitalityGym
{
    public partial class UserDashboard : Form
    {
        public UserDashboard()
        {
            InitializeComponent();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            AccountDetails account = new AccountDetails();
            account.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserLogin login = new UserLogin();
            login.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BuyPackage pack = new BuyPackage();
            pack.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Package Cancelled:(");
        }
    }
}
