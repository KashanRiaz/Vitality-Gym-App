﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VitalityGym
{
    public partial class AccountDetails : Form
    {

        private void RetrieveClientData()
        {
            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection connection = new SqlConnection(path);
            connection.Open();

            string query = "SELECT clientname, clientemail, clientcity, clientpackage, clientpassword FROM Client WHERE clientemail = 'haseeb1@gmail.com'";
            SqlCommand command = new SqlCommand(query, connection);

            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                string name = reader["clientname"].ToString();
                string email = reader["clientemail"].ToString();
                string city = reader["clientcity"].ToString();
                string packages = reader["clientpackage"].ToString();
                string password = reader["clientpassword"].ToString();

                // Assuming you have separate textboxes to display the values
                textBox1.Text = name;
                textBox2.Text = email;
                textBox3.Text = city;
                textBox4.Text = packages;
                textBox5.Text = password;
            }

            reader.Close();
            connection.Close();
        }

        public AccountDetails()
        {
            InitializeComponent();
        }

        private void AccountDetails_Load(object sender, EventArgs e)
        {
            this.clientTableAdapter.Fill(this.vitality.Client);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserDashboard user = new UserDashboard();
            user.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RetrieveClientData();
        }
    }
}
