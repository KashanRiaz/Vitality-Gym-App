﻿namespace VitalityGym
{
    partial class TrainerDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrainerDetails));
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.trainernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainerpasswordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainercityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.traineremailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainersalaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vitalityDataSet1 = new VitalityGym.VitalityDataSet1();
            this.vitality = new VitalityGym.Vitality();
            this.vitalityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.trainerTableAdapter = new VitalityGym.VitalityDataSet1TableAdapters.TrainerTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vitalityDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vitality)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vitalityBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(36)))), ((int)(((byte)(71)))));
            this.button1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.69307F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(563, 461);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 59);
            this.button1.TabIndex = 61;
            this.button1.Text = "Show";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 126);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 60;
            this.pictureBox1.TabStop = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(36)))), ((int)(((byte)(71)))));
            this.button5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.69307F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(285, 461);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(138, 59);
            this.button5.TabIndex = 59;
            this.button5.Text = "Close";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.66337F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(36)))), ((int)(((byte)(71)))));
            this.label1.Location = new System.Drawing.Point(278, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(437, 39);
            this.label1.TabIndex = 58;
            this.label1.Text = "T R A I N E R  D E T A I L S";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.trainernameDataGridViewTextBoxColumn,
            this.trainerpasswordDataGridViewTextBoxColumn,
            this.trainercityDataGridViewTextBoxColumn,
            this.traineremailDataGridViewTextBoxColumn,
            this.trainersalaryDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.trainerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(213, 154);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 43;
            this.dataGridView1.Size = new System.Drawing.Size(571, 245);
            this.dataGridView1.TabIndex = 57;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // trainernameDataGridViewTextBoxColumn
            // 
            this.trainernameDataGridViewTextBoxColumn.DataPropertyName = "trainername";
            this.trainernameDataGridViewTextBoxColumn.HeaderText = "trainername";
            this.trainernameDataGridViewTextBoxColumn.Name = "trainernameDataGridViewTextBoxColumn";
            this.trainernameDataGridViewTextBoxColumn.Width = 105;
            // 
            // trainerpasswordDataGridViewTextBoxColumn
            // 
            this.trainerpasswordDataGridViewTextBoxColumn.DataPropertyName = "trainerpassword";
            this.trainerpasswordDataGridViewTextBoxColumn.HeaderText = "trainerpassword";
            this.trainerpasswordDataGridViewTextBoxColumn.Name = "trainerpasswordDataGridViewTextBoxColumn";
            this.trainerpasswordDataGridViewTextBoxColumn.Width = 105;
            // 
            // trainercityDataGridViewTextBoxColumn
            // 
            this.trainercityDataGridViewTextBoxColumn.DataPropertyName = "trainercity";
            this.trainercityDataGridViewTextBoxColumn.HeaderText = "trainercity";
            this.trainercityDataGridViewTextBoxColumn.Name = "trainercityDataGridViewTextBoxColumn";
            this.trainercityDataGridViewTextBoxColumn.Width = 105;
            // 
            // traineremailDataGridViewTextBoxColumn
            // 
            this.traineremailDataGridViewTextBoxColumn.DataPropertyName = "traineremail";
            this.traineremailDataGridViewTextBoxColumn.HeaderText = "traineremail";
            this.traineremailDataGridViewTextBoxColumn.Name = "traineremailDataGridViewTextBoxColumn";
            this.traineremailDataGridViewTextBoxColumn.Width = 105;
            // 
            // trainersalaryDataGridViewTextBoxColumn
            // 
            this.trainersalaryDataGridViewTextBoxColumn.DataPropertyName = "trainersalary";
            this.trainersalaryDataGridViewTextBoxColumn.HeaderText = "trainersalary";
            this.trainersalaryDataGridViewTextBoxColumn.Name = "trainersalaryDataGridViewTextBoxColumn";
            this.trainersalaryDataGridViewTextBoxColumn.Width = 105;
            // 
            // trainerBindingSource
            // 
            this.trainerBindingSource.DataMember = "Trainer";
            this.trainerBindingSource.DataSource = this.vitalityDataSet1;
            // 
            // vitalityDataSet1
            // 
            this.vitalityDataSet1.DataSetName = "VitalityDataSet1";
            this.vitalityDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vitality
            // 
            this.vitality.DataSetName = "Vitality";
            this.vitality.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vitalityBindingSource
            // 
            this.vitalityBindingSource.DataSource = this.vitality;
            this.vitalityBindingSource.Position = 0;
            // 
            // trainerTableAdapter
            // 
            this.trainerTableAdapter.ClearBeforeFill = true;
            // 
            // TrainerDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(940, 564);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "TrainerDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TrainerDetails";
            this.Load += new System.EventHandler(this.TrainerDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vitalityDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vitality)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vitalityBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource vitalityBindingSource;
        private Vitality vitality;
        private VitalityDataSet1 vitalityDataSet1;
        private System.Windows.Forms.BindingSource trainerBindingSource;
        private VitalityDataSet1TableAdapters.TrainerTableAdapter trainerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainerpasswordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainercityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn traineremailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainersalaryDataGridViewTextBoxColumn;
    }
}