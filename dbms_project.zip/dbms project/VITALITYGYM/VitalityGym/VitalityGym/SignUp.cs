﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace VitalityGym
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            UserLogin user = new UserLogin();
            user.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string Name = textBox1.Text;
            string Email = textBox2.Text;
            string City = textBox4.Text;
            string Package = textBox3.Text;
            string Password = textBox4.Text;

            Insert(Name, Email, City, Package, Password);

            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
            textBox5.Text = string.Empty;

            MessageBox.Show("Registered Successfully");
        }
        public void Insert(string name, string email, string city, string package, string password)
        {
            string path = @"Data Source=LAPTOP-HN8BPIFD\SQLEXPRESS;Initial Catalog=Vitality;Integrated Security=True";
            SqlConnection Connection = new SqlConnection(path);
            Connection.Open();
            string query = "INSERT INTO client (clientname, clientemail, clientcity, clientpackage, clientpassword) VALUES (@name, @email, @city, @package, @password)";
            using (SqlCommand command = new SqlCommand(query, Connection))
            {
                command.Parameters.AddWithValue("@name", name);
                command.Parameters.AddWithValue("@email", email);
                command.Parameters.AddWithValue("@city", city);
                command.Parameters.AddWithValue("@package", package);
                command.Parameters.AddWithValue("@password", password);

                command.ExecuteNonQuery();
                command.Dispose();


            }
            Connection.Close();
        }
    }
}
